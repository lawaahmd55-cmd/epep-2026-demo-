const tabs = document.querySelectorAll('.tab');
const panels = document.querySelectorAll('.panel');
tabs.forEach(tab => tab.addEventListener('click', () => {
  tabs.forEach(t => t.classList.toggle('active', t === tab));
  panels.forEach(p => p.classList.toggle('active', p.id === tab.dataset.tab));
}));

const dialog = document.querySelector('#renameDialog');
const input = document.querySelector('#newName');
const openButtons = [document.querySelector('#renameOpen'), document.querySelector('#renameOpen2')];
openButtons.forEach(button => button.addEventListener('click', () => {
  input.value = document.querySelector('#heroName').textContent;
  dialog.showModal();
}));
document.querySelector('#renameForm').addEventListener('submit', event => {
  event.preventDefault();
  const name = input.value.trim();
  if (name.length < 2 || name.length > 18) return;
  document.querySelector('#heroName').textContent = name.toUpperCase();
  document.querySelector('#profileName').textContent = name.toUpperCase();
  dialog.close();
});
document.querySelector('#saveName').addEventListener('click', event => {
  if (!input.value.trim()) { event.preventDefault(); input.focus(); }
});

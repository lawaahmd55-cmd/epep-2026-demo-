# EPEP 2026 — Fan-made Lobby Demo

Project website statis berupa simulasi lobby game. Ini **bukan** cheat, mod APK, unlocker, atau alat untuk mengubah akun/server Free Fire. Skin dan senjata di halaman ini hanya kartu ilustrasi demo.

## Jalankan di perangkat
1. Ekstrak ZIP.
2. Buka `index.html` di browser, atau gunakan ekstensi Live Server di editor kode.
3. Semua file utama (`index.html`, `style.css`, `script.js`) harus tetap berada dalam satu folder.

## Pasang ke GitHub Pages
1. Masuk ke GitHub dan buat repository baru, misalnya `epep-2026-demo`.
2. Upload `index.html`, `style.css`, `script.js`, dan `README.md` ke root repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/(root)`, lalu tekan **Save**.
6. Tunggu proses selesai. URL website akan muncul di bagian GitHub Pages.

## Kustomisasi
- Ubah nama awal pada elemen `heroName` dan `profileName` di `index.html`.
- Ubah warna, layout, dan efek di `style.css`.
- Ubah daftar kartu skin/senjata demo di `index.html`.

## Batasan
Fitur rename hanya mengubah nama yang terlihat di halaman demo. Tidak mengubah nickname akun game. Tidak ada koneksi ke server game, tidak membuka item berbayar, dan tidak mengakses data akun.
